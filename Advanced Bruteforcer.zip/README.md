# 🔑 BruteForcer

A brute forcer that takes an **IP address**, **username**, and a `passlist.txt` file to try passwords.

## Features
- IP + username input
- Reads from `passlist.txt`
- Logs attempts with timestamps
- Simple CLI usage
